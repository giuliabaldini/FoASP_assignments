% FASP - Sheet4 - Giulia Baldini, Luis Fernandes, Agustin Vargas

f_s = 1000;
duration = 5;
f_0 = 0;
k = [2, 4, 6, 8, 10];

Sheet4Exercise4_4a(duration, f_s, k, f_0)
