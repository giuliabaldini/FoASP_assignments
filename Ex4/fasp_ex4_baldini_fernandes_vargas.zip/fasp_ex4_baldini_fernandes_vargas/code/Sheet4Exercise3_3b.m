% FASP - Sheet4 - Giulia Baldini, Luis Fernandes, Agustin Vargas

Sheet4Exercise3_3a([1, 2, 3, 4, 10])