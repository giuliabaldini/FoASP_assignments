% FASP - Sheet5 - Giulia Baldini, Luis Fernandes, Agustin Vargas
% AKA. The longest script ever.
Sheet5Exercise3(0.7, 1 , 0, 5, 20:200)